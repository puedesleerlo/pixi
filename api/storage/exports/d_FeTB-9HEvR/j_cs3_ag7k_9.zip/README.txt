PIXIE export of deck 'Export deck' (export-deck). Readings are anonymised. Every metric in grammar.csv is recomputable from readings.csv and manifest.json (see docs/SPEC-v5.md §8).
